library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity speed_controller is
    Port (
        clk          : in  STD_LOGIC;
        rst          : in  STD_LOGIC;
        hit_detected : in  STD_LOGIC;  -- 1-taktni pulz pri uspesnem odpalu
        tick_limit   : out integer range 0 to 15_000_000
    );
end speed_controller;

architecture Behavioral of speed_controller is
    constant ODPALY_PRO_ZRYCHLENI : integer := 2;
    constant MAX_COUNT            : integer := (3 * ODPALY_PRO_ZRYCHLENI) - 1;  -- 14

    signal hit_count : integer range 0 to MAX_COUNT := 0;
begin

    -- Citac uspesnych odpalu
    counter_proc : process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                hit_count <= 0;
            elsif hit_detected = '1' then
                if hit_count < MAX_COUNT then
                    hit_count <= hit_count + 1;
                end if;
            end if;
        end if;
    end process;

    -- Vyber rychlosti podle poctu odpalu (vyssi pocet = nizsi tick_limit = rychlejsi micek)
    tick_limit <= 15_000_000 when hit_count < ODPALY_PRO_ZRYCHLENI       -- Uroven 0: 150 ms
             else 12_500_000  when hit_count < (2 * ODPALY_PRO_ZRYCHLENI) -- Uroven 1: 75 ms
             else 10_000_000  when hit_count < (3 * ODPALY_PRO_ZRYCHLENI)
             else 7_500_000  when hit_count < (4 * ODPALY_PRO_ZRYCHLENI)
             else 5_000_000;                                             -- Uroven 2: 50 ms

end Behavioral;
