library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity GameLogic is
    Port ( 
           clk      : in STD_LOGIC;
           rst      : in STD_LOGIC;
           player_L : in STD_LOGIC;
           player_R : in STD_LOGIC;
           
           seg      : out STD_LOGIC_VECTOR (6 downto 0);
           led      : out STD_LOGIC_VECTOR (15 downto 0);
           led16_b  : out STD_LOGIC;
           anode    : out STD_LOGIC_VECTOR (7 downto 0);
           dp       : out STD_LOGIC);
end GameLogic;

architecture Behavioral of GameLogic is 

    -- Komponenty
    component clk_en is
        Port ( clk   : in STD_LOGIC;
               rst   : in STD_LOGIC;
               v_max : in integer range 0 to 200_000_000;
               ce    : out STD_LOGIC);
    end component;
    
    component display_driver is
        Port ( clk   : in STD_LOGIC;
               rst   : in STD_LOGIC;
               data  : in STD_LOGIC_VECTOR (39 downto 0);
               seg   : out STD_LOGIC_VECTOR (6 downto 0);
               anode : out STD_LOGIC_VECTOR (7 downto 0));
    end component;

    component speed_controller is
        Port ( clk          : in  STD_LOGIC;
               rst          : in  STD_LOGIC;
               hit_detected : in  STD_LOGIC;
               tick_limit   : out integer range 0 to 200_000_000);
    end component;

    -- Signály
    constant WIN_SCORE : integer := 10;
    signal reset_request  : STD_LOGIC;
    signal player_R_score : integer range 0 to WIN_SCORE;
    signal player_L_score : integer range 0 to WIN_SCORE;
    signal ball_position  : STD_LOGIC_VECTOR(15 downto 0);
    signal display_text   : STD_LOGIC;
    signal displayed_text : STD_LOGIC_VECTOR(39 downto 0);
    signal ball_direction : STD_LOGIC; -- '1' vlevo, '0' vpravo
    signal ball_tick      : STD_LOGIC;

    -- Signály pro dynamickou rychlost
    signal s_hit_detected : STD_LOGIC;
    signal s_ball_speed   : integer range 0 to 200_000_000;
    
    type state_type is (IDLE, START, PLAYING, END_OF_ROUND, END_OF_GAME);
    signal game_state : state_type;

begin

    -- Instance speed controlleru
    speed_ctrl0 : speed_controller
        port map (
            clk => clk,
            rst => reset_request,
            hit_detected => s_hit_detected,
            tick_limit => s_ball_speed
        );

    -- Časovač pro textové zprávy (2 sekundy)
    clock_text : clk_en
        port map (
            clk => clk,
            rst => reset_request,
            v_max => 200_000_000,
            ce  => display_text
        );
    
    -- Časovač pro pohyb míčku (dynamický)
    clock_ball : clk_en
        port map (
            clk => clk,
            rst => reset_request,
            v_max => s_ball_speed,
            ce => ball_tick
        );

    -- Ovladač 7-segmentového displeje
    display0 : display_driver
        port map (
            clk => clk,
            rst => rst,
            data => displayed_text,
            seg => seg,
            anode => anode
        );
    
    led <= ball_position;
    
    game_process: process(clk)
    begin
        if rising_edge(clk) then
            s_hit_detected <= '0'; -- Defaultní stav pulsu

            if(rst = '1') then
                player_L_score  <= 0;
                player_R_score  <= 0;
                ball_position   <= b"0000_0001_1000_0000";
                displayed_text  <= (others => '1');
                led16_b         <= '0';
                reset_request   <= '1';
                game_state      <= IDLE;
            else
                case game_state is
                    
                    when IDLE =>
                        if(player_L = '1' OR player_R = '1') then
                            reset_request <= '1';
                            game_state <= START;
                        else
                            -- Zobrazení skóre L a R
                            displayed_text <= "10010" & "10000" & std_logic_vector(to_unsigned(player_L_score, 5)) & "11111" & "10001" & "10000" & std_logic_vector(to_unsigned(player_R_score, 5)) & "11111";
                        end if;
                        
                    when START =>
                        reset_request <= '0';
                        displayed_text <= b"11111_11111_10001_10010_10011_10100_11111_11111"; -- "PLAY"
                        if (display_text = '1') then
                            -- Určení směru (podle toho kdo prohrál nebo vede)
                            if(player_L_score >= player_R_score) then ball_direction <= '1';
                            else ball_direction <= '0';
                            end if;
                            game_state <= PLAYING;
                        end if;
                    
                    when PLAYING =>
                        displayed_text <= (others => '1');
                        led16_b <= '1';
                        reset_request <= '0';
                        s_hit_detected <= '0';
                        
                        -- Detekce odrazu
                        if (player_L = '1' and ball_position(15) = '1') then
                            ball_direction <= '0';
                            ball_position <= '0' & ball_position(15 downto 1);
                            reset_request <= '1';
                            s_hit_detected <= '1'; -- Zrychlí hru
                            
                        elsif (player_R = '1' and ball_position(0) = '1') then
                            ball_direction <= '1';
                            ball_position <= ball_position(14 downto 0) & '0';
                            reset_request <= '1';
                            s_hit_detected <= '1'; -- Zrychlí hru
                        end if;

                        -- Automatický pohyb míčku
                        if (ball_tick = '1') then
                            if(ball_direction = '1') then -- Doleva
                                if(ball_position(15) = '1') then
                                    player_R_score <= player_R_score + 1;
                                    game_state <= END_OF_ROUND;
                                else
                                    ball_position <= ball_position(14 downto 0) & '0';
                                end if;
                            else -- Doprava
                                if(ball_position(0) = '1') then
                                    player_L_score <= player_L_score + 1;
                                    game_state <= END_OF_ROUND;
                                else
                                    ball_position <= '0' & ball_position(15 downto 1);
                                end if;
                            end if;
                        end if;
                    
                    when END_OF_ROUND =>
                        ball_position <= b"0000_0001_1000_0000";
                        reset_request <= '1'; -- Resetuje rychlost pro nové kolo
                        if(player_L_score = WIN_SCORE OR player_R_score = WIN_SCORE) then
                            game_state <= END_OF_GAME;
                        else
                            game_state <= IDLE;
                        end if;
                    
                    when END_OF_GAME =>
                        -- Blikání LED pole
                        if (ball_tick = '1') then
                            if (ball_position(15) = '1') then ball_position <= (others => '0');
                            else ball_position <= (others => '1');
                            end if;
                        end if;
                        -- Zobrazení vítěze
                        if (player_L_score = WIN_SCORE) then
                            displayed_text <= b"10001_10010_10011_10100_10101_10110_11111_00001"; -- PLAYER 1
                        else
                            displayed_text <= b"10001_10010_10011_10100_10101_10110_11111_00010"; -- PLAYER 2
                        end if;
                    
                    when others =>
                        game_state <= IDLE;
                end case;
            end if;
        end if;
    end process;
end Behavioral;