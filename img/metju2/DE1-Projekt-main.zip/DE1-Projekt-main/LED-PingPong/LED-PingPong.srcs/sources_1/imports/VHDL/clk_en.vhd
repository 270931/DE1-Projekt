library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity clk_en is
    Port ( 
        clk   : in  STD_LOGIC;
        rst   : in  STD_LOGIC;
        v_max : in  integer range 0 to 200_000_000; 
        ce    : out STD_LOGIC
    );
end clk_en;

architecture Behavioral of clk_en is
    signal count : integer range 0 to 200_000_000 := 0;
begin
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                count <= 0;
                ce <= '0';
            elsif count >= v_max then
                count <= 0;
                ce <= '1';
            else
                count <= count + 1;
                ce <= '0';
            end if;
        end if;
    end process;
end Behavioral;