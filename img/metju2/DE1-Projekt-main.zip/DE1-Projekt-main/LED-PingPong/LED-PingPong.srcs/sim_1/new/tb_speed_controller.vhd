library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_speed_controller is
end tb_speed_controller;

architecture test of tb_speed_controller is

    -- 1. Deklarace komponenty (místo přímého volání entity)
    component speed_controller is
        Port (
            clk          : in  STD_LOGIC;
            rst          : in  STD_LOGIC;
            hit_detected : in  STD_LOGIC;
            tick_limit   : out integer range 0 to 200_000_000
        );
    end component;

    -- Signály pro propojení
    signal s_clk          : STD_LOGIC := '0';
    signal s_rst          : STD_LOGIC := '0';
    signal s_hit_detected : STD_LOGIC := '0';
    signal s_tick_limit   : integer range 0 to 200_000_000;

    constant CLK_PERIOD : time := 10 ns;

begin

    -- 2. Instance pomocí komponenty
    uut: speed_controller
        port map (
            clk          => s_clk,
            rst          => s_rst,
            hit_detected => s_hit_detected,
            tick_limit   => s_tick_limit
        );

    -- Hodiny
    clk_process : process
    begin
        s_clk <= '0';
        wait for CLK_PERIOD / 2;
        s_clk <= '1';
        wait for CLK_PERIOD / 2;
    end process;

    -- Testovací scénář
    stim_proc: process
    begin
        -- Reset
        s_rst <= '1';
        s_hit_detected <= '0';
        wait for 100 ns;
        s_rst <= '0';
        wait for 100 ns;

        -- Simulace 30 hitů
        for i in 1 to 30 loop
            s_hit_detected <= '1';
            wait for CLK_PERIOD;
            s_hit_detected <= '0';
            
            -- Mezera mezi hity, aby to bylo v grafu vidět
            wait for CLK_PERIOD * 10;
        end loop;

        wait for 200 ns;
        wait;
    end process;

end test;